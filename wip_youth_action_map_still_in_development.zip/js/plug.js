"use strict";

(function(window, document, undefined){
	


})(this, document);


// (function ( $ ) {
// Put other Jquery operations in here without conflict.
// Example:

// jQuery.fn.visible = function() {
//     return this.css('visibility', 'visible');
// };

// jQuery.fn.invisible = function() {
//     return this.css('visibility', 'hidden');
// };



// }( jQuery ));
